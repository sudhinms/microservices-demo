package com.microservices.full.serviceconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
